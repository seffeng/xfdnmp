.. cmake-module:: ../../Modules/CPackBundle.cmake
