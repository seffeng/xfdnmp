.. cmake-module:: ../../Modules/Use_wxWindows.cmake
