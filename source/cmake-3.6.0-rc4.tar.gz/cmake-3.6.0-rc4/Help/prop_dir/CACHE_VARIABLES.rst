CACHE_VARIABLES
---------------

List of cache variables available in the current directory.

This read-only property specifies the list of CMake cache variables
currently defined.  It is intended for debugging purposes.
